#!/usr/bin/env python3
"""离线安装分享包中的 Fresh Chat Handoff 技能，不修改 Memories 或配置。"""
import argparse
import os
from pathlib import Path
import shutil
import sys

SKILL_NAME = "fresh-chat-handoff"


def install(source, skills_dir):
    source = Path(source)
    skills_dir = Path(skills_dir).expanduser()
    target = skills_dir / SKILL_NAME
    required = ("SKILL.md", "agents/openai.yaml")
    for relative in required:
        item = source / relative
        if not item.is_file() or item.is_symlink():
            raise ValueError("分享包缺少有效文件：" + relative)

    if target.is_symlink():
        raise FileExistsError("目标是符号链接，不自动替换：" + str(target))
    if target.exists():
        if not target.is_dir():
            raise FileExistsError("目标不是目录，不自动替换：" + str(target))
        expected = set(required)
        actual = {str(p.relative_to(target)).replace(os.sep, "/")
                  for p in target.rglob("*") if p.is_file() or p.is_symlink()}
        identical = actual == expected and all(
            not (target / relative).is_symlink()
            and (target / relative).read_bytes() == (source / relative).read_bytes()
            for relative in required
        )
        if identical:
            return target, False
        raise FileExistsError("目标已有不同内容，未覆盖。请检查后自行处理：" + str(target))

    skills_dir.mkdir(parents=True, exist_ok=True)
    target.mkdir()  # 独占创建；有并发或同名目录时直接失败，不覆盖。
    for relative in required:
        destination = target / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        with destination.open("xb") as stream:
            stream.write((source / relative).read_bytes())
    return target, True


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--skills-dir", type=Path,
        default=Path.home() / ".agents" / "skills",
        help="安装到技能根目录；默认 ~/.agents/skills；本机兼容位置可选 ~/.codex/skills",
    )
    args = parser.parse_args()
    source = Path(__file__).resolve().parent / SKILL_NAME
    try:
        target, created = install(source, args.skills_dir)
    except (OSError, ValueError) as error:
        print("安装失败：" + str(error), file=sys.stderr)
        return 1
    print(("已安装：" if created else "已存在相同版本，无需修改：") + str(target))
    print("调用：$fresh-chat-handoff，或说“上下文快满了，整理摘要并开全新对话，不要分支”。")
    print("如果技能未出现在列表，重新打开 Codex 后再试。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
